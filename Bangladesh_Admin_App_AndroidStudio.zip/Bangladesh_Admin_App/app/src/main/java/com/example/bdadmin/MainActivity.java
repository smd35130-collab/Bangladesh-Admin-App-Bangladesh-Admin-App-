package com.example.bdadmin;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(8,127,91)); getWindow().setNavigationBarColor(Color.rgb(8,89,69));
 WebView w=new WebView(this); w.setBackgroundColor(Color.rgb(244,248,246)); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setWebChromeClient(new android.webkit.WebChromeClient()); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
 @Override public void onBackPressed(){setContentViewBack();}
 private void setContentViewBack(){super.onBackPressed();}
}