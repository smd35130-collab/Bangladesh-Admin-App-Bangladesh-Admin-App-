# বাংলাদেশ জেলা, উপজেলা ও যাতায়াত ভাড়া — Android project

বাংলা ইন্টারফেসে ৮ বিভাগ, ৬৪ জেলা, উপজেলা তালিকা, সার্চ এবং ঢাকা থেকে যাতায়াত ভাড়া-সংক্রান্ত তথ্য দেখানোর Android WebView অ্যাপ। উপজেলার নাম কপি করার সুবিধা নেই।

## APK তৈরি

এই ZIP-এ Android Studio project source আছে; এখানে তৈরি করা APK ফাইল নেই। Android SDK/Gradle-সহ build environment-এ নিচের ধাপগুলোতে ইনস্টলযোগ্য debug APK তৈরি করা যায়।

### Android Studio দিয়ে
1. ZIP extract করে Android Studio-তে project folder খুলুন।
2. Gradle sync সম্পূর্ণ হতে দিন এবং SDK Platform 35 ইনস্টল করুন।
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)** নির্বাচন করুন।
4. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk` ফাইলে। এই debug APK ফোনে ইনস্টল করার উপযোগী।

### GitHub Actions দিয়ে
প্রজেক্টটি GitHub repository-তে push করার পর **Actions** tab খুলে **Build installable Android APK** workflow চালান। কাজ সফল হলে run-এর **Artifacts** অংশ থেকে `Bangladesh-Admin-App-APK` ডাউনলোড করুন; ZIP extract করে `app-debug.apk` ফোনে ইনস্টল করুন।

## ব্যবহার
- জেলা, উপজেলা ও ভাড়া তালিকার জন্য উপরের কার্ড নির্বাচন করুন।
- প্রথমবার পূর্ণ ভৌগোলিক ডেটা লোড করতে ইন্টারনেট প্রয়োজন; সফল হলে ডেটা cache হতে পারে।
- ভাড়া অংশে দেখানো তথ্য সাধারণ/সরকারি হার ও যাচাইয়ের লিংক; প্রতিটি জেলা-রুটের নির্দিষ্ট বাস/ট্রেন টিকিটের দাম নিশ্চিত করে না।

## প্রযুক্তি
- Android Java WebView
- `minSdk 23`, `compileSdk 35`, Android Gradle Plugin 8.7.3
